package com.sql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class JdbcPractice {

	public static void main(String[] args) {
		String url="jdbc:mysql://localhost:3306/chandana";
				String user="root";
				String password="Dasarisai@9963";
			
				try (Connection con=DriverManager.getConnection(url,user,password)){
					Class.forName("com.mysql.cj.jdbc.Driver");
					Statement st=con.createStatement();
					ResultSet rs=st.executeQuery("select*from student");
					while(rs.next())
					{
						System.out.println(rs.getInt("sid")+ "|" +rs.getString("sname")+ "|" +rs.getDate("sdob1")+ "|" +rs.getString("sadd"));
					}
					
					
					
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				}
	}


