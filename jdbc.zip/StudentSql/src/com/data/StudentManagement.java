package com.data;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class StudentManagement {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String url="jdbc:mysql://localhost:3306/chandana";
		//String user="root";
		//String password="Dasarisai@9963";
	
		System.out.println("Enter user name");
		String user=sc.next();
		System.out.println("Enter password");
		String password1=sc.next();
	    System.out.println("Welcome to student management system");
	    int sid=sc.nextInt();
	    String sname=sc.next();
	    String sadd=sc.next();
	    String password =sc.next();
	    
		try (Connection con=DriverManager.getConnection(url,user,password1)){
			Class.forName("com.mysql.cj.jdbc.Driver");
			Statement st=con.createStatement();
			int id1;
			id1=sc.nextInt();
			switch(id1) {
			case 1:
			int i= st.executeUpdate("insert into student2 values("+sid+",'"+sname+"','"+sadd+"','"+password+"')");
			if(i>0) {
				System.out.println("values got inserted");
			}
			else {
				System.out.println("values get failed");
			}
			case 2:
			int j=st.executeUpdate("delete from student2 where ('"+password+"'=null)");
			if(j<0) {
				System.out.println("value get deleted");
			}
			else {
				System.out.println("value not deleted");
			}
			case 0:
			if(sid==0) {
				int id;
				String s1;
				System.out.println("enter id and name");
				id=sc.nextInt();
				s1=sc.next();
			int k=st.executeUpdate("update student2 set sname='"+s1+"' where sid="+id+"");
			
			if(k<0) {
				System.out.println("value get updated");
			}
			else {
				System.out.println("value not updated");
			}
			}
			case 4:
			ResultSet rs=st.executeQuery("select*from student2");
			while(rs.next())
			{
				System.out.println(rs.getInt("sid")+ "|" +rs.getString("sname")+ "|"  +rs.getString("sadd")+ "|" +rs.getString("password"));
			}
			case 5:
			System.out.println("exit");
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		}
		
}
}


